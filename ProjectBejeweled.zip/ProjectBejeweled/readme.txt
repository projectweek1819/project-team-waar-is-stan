Wegens slecht tijdmanagement tussen de oefeningenreeksen en ons project hebben we niet veel van een proejct om af te leveren.
Desondanks hebben we wel hard gewerk aan onze oefeningen en deze vindt u dan ook in het bestand. Ook kan u het ontwerp vinden 
van ons project.